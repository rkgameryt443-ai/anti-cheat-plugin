# SentinelAC

Anti-cheat plugin for Paper 1.21+. Broad detection across movement, combat,
world-interaction, and basic packet-integrity checks, with a fully
config-driven punishment escalation system.

## Building

Requires JDK 21 and Maven.

```
mvn clean package
```

The output jar will be in `target/SentinelAC-1.0.0.jar`. Drop it in your
server's `plugins/` folder and restart.

**Note:** this was written and reviewed carefully but not compiled against
a live Paper API jar in the environment it was built in (sandboxed, no
network access to repo.papermc.io). Treat your first `mvn package` as the
real correctness check — if anything fails to compile, paste me the error
and I'll fix it immediately.

## What's included

**Movement** (`checks/movement/`)
- `FlightCheck` — sustained unsupported airtime without expected gravity trend
- `SpeedCheck` — horizontal speed beyond dynamic, state-aware cap
- `NoFallCheck` — ground-spoofing to cancel fall damage
- `JesusCheck` — walking on liquid surfaces
- `PhaseCheck` — moving into solid full-cube blocks (no-clip)
- `StepCheck` — climbing steps taller than vanilla's 0.6 block limit

**Combat** (`checks/combat/`)
- `KillAuraCheck` — attacking targets outside plausible view-angle cone
- `ReachCheck` — melee hits beyond ~3.1 blocks
- `AutoClickerCheck` — CPS ceiling + click-interval variance analysis
- `VelocityCheck` — anti-knockback / velocity-cancel detection

**World** (`checks/world/`)
- `FastBreakCheck` — breaking blocks faster than hardness allows
- `FastPlaceCheck` — block placement rate beyond manual-click ceiling
- `ScaffoldCheck` — auto-bridge placement without looking down

**Packet integrity** (`checks/packet/`)
- `BadPacketsCheck` — NaN/infinite coordinates, invalid pitch, out-of-border movement
- `TimerCheck` — movement packet frequency above 20/sec (timer hacks)

Every check is independently toggleable in `config.yml` and reads its own
threshold values from there too, so you can tune sensitivity per-check
without touching code.

## Punishment system

Fully configurable in `config.yml` under `punishments`. There's a
`default` escalation ladder (alert → kick → ban) and you can add
per-check `overrides` (a stricter ladder for KillAura is included as an
example). Each stage fires once, the first time a player's violation
level (VL) for that check reaches the threshold.

Supported command types per stage:
- `console:<command>` — run any command as console
- `broadcast:<message>` — server-wide broadcast (supports `&` color codes)
- `kick` — kick with a generic message
- `ban` — ban by name
- `ban-ip` — ban by IP

VLs decay by 1 every `settings.violation-decay-seconds` (default 30s) of
no new violations on that check, so a one-off false positive from lag
doesn't snowball into a punishment.

## Commands

- `/sentinel reload` — reload config.yml
- `/sentinel check <player>` — view a player's current VLs per check
- `/sentinel exempt <player> [seconds]` — temporarily exempt a player from all checks (default 60s)
- `/sentinel resetviolations <player>` — clear all VLs for a player

Permissions: `sentinelac.admin` (commands), `sentinelac.alerts` (receive
real-time alerts), `sentinelac.bypass` (exempt from all checks).

## Known limitations / next steps

This is built entirely on Bukkit/Paper events (no packet library
dependency), which keeps it dependency-free but means a few checks are
proxies rather than ground-truth:

- **TimerCheck** counts `PlayerMoveEvent` frequency, which Paper may
  coalesce slightly differently than raw packets. For stricter accuracy,
  wire it into a [ProtocolLib](https://www.spigotmc.org/resources/protocollib.1997/)
  `PacketListener` on `PacketType.Play.Client.POSITION` instead.
- **KillAura / Reach** rely on `EntityDamageByEntityEvent`, which fires
  after the hit registers server-side — good enough for most cases, but a
  packet-level check could catch attacks the server never processes as
  damage (e.g., swing-spam at an empty space).
- Movement checks use simplified physics approximations (not exact
  vanilla floating-point replication), tuned conservatively to minimize
  false positives. Expect to tune thresholds in `config.yml` against your
  actual playerbase's ping/hardware profile.
- No NoSlow (block-while-eating/shielding) or Inventory-move checks yet —
  natural additions if you want to expand coverage.

## Testing recommendations

1. Start with `settings.debug: true` to get console logging on every flag.
2. Have a trusted player test legitimate edge cases first: elytra flight,
   boats, ice slides, potions of speed/jump boost, lag spikes (alt-tab
   the client for a few seconds) — confirm none of these false-positive.
3. Only then have someone test with an actual hacked client (in a
   controlled environment) to confirm detection and tune `max-violations-before-action`.
4. Adjust `punishments` stages once you're confident in detection accuracy.
