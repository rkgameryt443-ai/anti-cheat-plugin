package com.anticheat.data;

import org.bukkit.entity.Player;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Central registry of PlayerData objects, keyed by UUID.
 * Thread-safe since packet listeners may run off the main thread.
 */
public class PlayerDataManager {

    private final Map<UUID, PlayerData> dataMap = new ConcurrentHashMap<>();

    public PlayerData get(Player player) {
        return dataMap.computeIfAbsent(player.getUniqueId(), uuid -> new PlayerData(uuid));
    }

    public PlayerData get(UUID uuid) {
        return dataMap.get(uuid);
    }

    public void remove(Player player) {
        dataMap.remove(player.getUniqueId());
    }

    public void clear() {
        dataMap.clear();
    }

    public int size() {
        return dataMap.size();
    }
}
