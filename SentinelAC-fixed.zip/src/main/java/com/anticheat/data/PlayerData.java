package com.anticheat.data;

import org.bukkit.Location;
import org.bukkit.entity.Player;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.UUID;

/**
 * Holds rolling state for a single player, used by all checks.
 * One instance per online player, created on join and cleared on quit.
 */
public class PlayerData {

    private final UUID uuid;

    // --- Movement tracking ---
    private Location lastLocation;
    private Location lastGroundLocation;
    private long lastMoveTime;
    private boolean wasOnGround;
    private int airTicks;
    private int groundTicks;
    private double lastDeltaY;
    private boolean justTeleported;
    private long teleportExpiry;
    private boolean inVehicle;
    private boolean isGliding;
    private boolean isSwimming;
    private boolean isFlyingAllowed; // creative/spectator/allowed-flight

    // --- Combat tracking ---
    private long lastAttackTime;
    private final Deque<Long> recentClicks = new ArrayDeque<>();
    private float lastYawAtAttack;
    private float lastPitchAtAttack;
    private double lastAttackDistance;
    private long lastVelocityApplied;
    private double lastKnockbackX;
    private double lastKnockbackY;
    private double lastKnockbackZ;

    // --- Packet / timer tracking ---
    private long lastPacketTime;
    private int packetsThisTick;
    private long lastTimerCheckTime;
    private int timerPacketCount;

    // --- World interaction tracking ---
    private long lastBlockBreakTime;
    private long lastBlockPlaceTime;
    private Location lastBlockPlaceLocation;
    private int consecutivePlacements;

    // --- Exemption ---
    private boolean exempt;
    private long exemptUntil;

    public PlayerData(UUID uuid) {
        this.uuid = uuid;
        this.lastMoveTime = System.currentTimeMillis();
    }

    public UUID getUuid() {
        return uuid;
    }

    // Movement getters/setters
    public Location getLastLocation() { return lastLocation; }
    public void setLastLocation(Location lastLocation) { this.lastLocation = lastLocation; }

    public Location getLastGroundLocation() { return lastGroundLocation; }
    public void setLastGroundLocation(Location lastGroundLocation) { this.lastGroundLocation = lastGroundLocation; }

    public long getLastMoveTime() { return lastMoveTime; }
    public void setLastMoveTime(long lastMoveTime) { this.lastMoveTime = lastMoveTime; }

    public boolean wasOnGround() { return wasOnGround; }
    public void setWasOnGround(boolean wasOnGround) { this.wasOnGround = wasOnGround; }

    public int getAirTicks() { return airTicks; }
    public void setAirTicks(int airTicks) { this.airTicks = airTicks; }
    public void incrementAirTicks() { this.airTicks++; }
    public void resetAirTicks() { this.airTicks = 0; }

    public int getGroundTicks() { return groundTicks; }
    public void setGroundTicks(int groundTicks) { this.groundTicks = groundTicks; }
    public void incrementGroundTicks() { this.groundTicks++; }
    public void resetGroundTicks() { this.groundTicks = 0; }

    public double getLastDeltaY() { return lastDeltaY; }
    public void setLastDeltaY(double lastDeltaY) { this.lastDeltaY = lastDeltaY; }

    public boolean isJustTeleported() {
        if (justTeleported && System.currentTimeMillis() > teleportExpiry) {
            justTeleported = false;
        }
        return justTeleported;
    }

    public void markTeleported(long graceMs) {
        this.justTeleported = true;
        this.teleportExpiry = System.currentTimeMillis() + graceMs;
    }

    public boolean isInVehicle() { return inVehicle; }
    public void setInVehicle(boolean inVehicle) { this.inVehicle = inVehicle; }

    public boolean isGliding() { return isGliding; }
    public void setGliding(boolean gliding) { isGliding = gliding; }

    public boolean isSwimming() { return isSwimming; }
    public void setSwimming(boolean swimming) { isSwimming = swimming; }

    public boolean isFlyingAllowed() { return isFlyingAllowed; }
    public void setFlyingAllowed(boolean flyingAllowed) { isFlyingAllowed = flyingAllowed; }

    // Combat getters/setters
    public long getLastAttackTime() { return lastAttackTime; }
    public void setLastAttackTime(long lastAttackTime) { this.lastAttackTime = lastAttackTime; }

    public Deque<Long> getRecentClicks() { return recentClicks; }

    public void recordClick(long now) {
        recentClicks.addLast(now);
        // keep only last 2 seconds of clicks
        while (!recentClicks.isEmpty() && now - recentClicks.peekFirst() > 2000) {
            recentClicks.pollFirst();
        }
    }

    public int getClicksInWindow(long windowMs) {
        long now = System.currentTimeMillis();
        int count = 0;
        for (Long t : recentClicks) {
            if (now - t <= windowMs) count++;
        }
        return count;
    }

    public float getLastYawAtAttack() { return lastYawAtAttack; }
    public void setLastYawAtAttack(float lastYawAtAttack) { this.lastYawAtAttack = lastYawAtAttack; }

    public float getLastPitchAtAttack() { return lastPitchAtAttack; }
    public void setLastPitchAtAttack(float lastPitchAtAttack) { this.lastPitchAtAttack = lastPitchAtAttack; }

    public double getLastAttackDistance() { return lastAttackDistance; }
    public void setLastAttackDistance(double lastAttackDistance) { this.lastAttackDistance = lastAttackDistance; }

    public long getLastVelocityApplied() { return lastVelocityApplied; }
    public void setLastVelocityApplied(long lastVelocityApplied) { this.lastVelocityApplied = lastVelocityApplied; }

    public void setLastKnockback(double x, double y, double z) {
        this.lastKnockbackX = x;
        this.lastKnockbackY = y;
        this.lastKnockbackZ = z;
        this.lastVelocityApplied = System.currentTimeMillis();
    }

    public double getLastKnockbackX() { return lastKnockbackX; }
    public double getLastKnockbackY() { return lastKnockbackY; }
    public double getLastKnockbackZ() { return lastKnockbackZ; }

    // Packet/timer getters/setters
    public long getLastPacketTime() { return lastPacketTime; }
    public void setLastPacketTime(long lastPacketTime) { this.lastPacketTime = lastPacketTime; }

    public int getPacketsThisTick() { return packetsThisTick; }
    public void setPacketsThisTick(int packetsThisTick) { this.packetsThisTick = packetsThisTick; }
    public void incrementPacketsThisTick() { this.packetsThisTick++; }
    public void resetPacketsThisTick() { this.packetsThisTick = 0; }

    public long getLastTimerCheckTime() { return lastTimerCheckTime; }
    public void setLastTimerCheckTime(long lastTimerCheckTime) { this.lastTimerCheckTime = lastTimerCheckTime; }

    public int getTimerPacketCount() { return timerPacketCount; }
    public void setTimerPacketCount(int timerPacketCount) { this.timerPacketCount = timerPacketCount; }
    public void incrementTimerPacketCount() { this.timerPacketCount++; }
    public void resetTimerPacketCount() { this.timerPacketCount = 0; }

    // World interaction getters/setters
    public long getLastBlockBreakTime() { return lastBlockBreakTime; }
    public void setLastBlockBreakTime(long lastBlockBreakTime) { this.lastBlockBreakTime = lastBlockBreakTime; }

    public long getLastBlockPlaceTime() { return lastBlockPlaceTime; }
    public void setLastBlockPlaceTime(long lastBlockPlaceTime) { this.lastBlockPlaceTime = lastBlockPlaceTime; }

    public Location getLastBlockPlaceLocation() { return lastBlockPlaceLocation; }
    public void setLastBlockPlaceLocation(Location lastBlockPlaceLocation) { this.lastBlockPlaceLocation = lastBlockPlaceLocation; }

    public int getConsecutivePlacements() { return consecutivePlacements; }
    public void setConsecutivePlacements(int consecutivePlacements) { this.consecutivePlacements = consecutivePlacements; }
    public void incrementConsecutivePlacements() { this.consecutivePlacements++; }
    public void resetConsecutivePlacements() { this.consecutivePlacements = 0; }

    // Exemption (grace period after legitimate causes: elytra, potions, server lag spikes, etc.)
    public boolean isExempt() {
        if (exempt && System.currentTimeMillis() > exemptUntil) {
            exempt = false;
        }
        return exempt;
    }

    public void setExemptFor(long durationMs) {
        this.exempt = true;
        this.exemptUntil = System.currentTimeMillis() + durationMs;
    }

    public static PlayerData of(Player player) {
        return new PlayerData(player.getUniqueId());
    }
}
