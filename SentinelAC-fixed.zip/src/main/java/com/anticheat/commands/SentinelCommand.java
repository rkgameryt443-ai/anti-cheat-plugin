package com.anticheat.commands;

import com.anticheat.core.SentinelAC;
import com.anticheat.data.PlayerData;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Map;

public class SentinelCommand implements CommandExecutor {

    private final SentinelAC plugin;

    public SentinelCommand(SentinelAC plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("sentinelac.admin")) {
            sender.sendMessage(ChatColor.RED + "You don't have permission to use this command.");
            return true;
        }

        if (args.length == 0) {
            sendUsage(sender);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "reload" -> {
                plugin.reloadConfig();
                sender.sendMessage(plugin.colorize("&aSentinelAC config reloaded."));
            }
            case "check" -> {
                if (args.length < 2) {
                    sender.sendMessage(plugin.colorize("&cUsage: /sentinel check <player>"));
                    return true;
                }
                Player target = Bukkit.getPlayer(args[1]);
                if (target == null) {
                    sender.sendMessage(plugin.colorize("&cPlayer not found or offline."));
                    return true;
                }
                Map<String, Double> violations = plugin.getViolationManager().getAllViolations(target.getUniqueId());
                if (violations.isEmpty()) {
                    sender.sendMessage(plugin.colorize("&7" + target.getName() + " has no recorded violations."));
                } else {
                    sender.sendMessage(plugin.colorize("&6Violations for " + target.getName() + ":"));
                    violations.forEach((check, vl) ->
                            sender.sendMessage(plugin.colorize("  &7" + check + ": &e" + String.format("%.1f", vl))));
                }
            }
            case "exempt" -> {
                if (args.length < 2) {
                    sender.sendMessage(plugin.colorize("&cUsage: /sentinel exempt <player> [seconds]"));
                    return true;
                }
                Player target = Bukkit.getPlayer(args[1]);
                if (target == null) {
                    sender.sendMessage(plugin.colorize("&cPlayer not found or offline."));
                    return true;
                }
                long seconds = args.length >= 3 ? parseLongSafe(args[2], 60) : 60;
                PlayerData data = plugin.getPlayerDataManager().get(target);
                data.setExemptFor(seconds * 1000);
                sender.sendMessage(plugin.colorize("&a" + target.getName() + " exempted from checks for " + seconds + "s."));
            }
            case "resetviolations" -> {
                if (args.length < 2) {
                    sender.sendMessage(plugin.colorize("&cUsage: /sentinel resetviolations <player>"));
                    return true;
                }
                Player target = Bukkit.getPlayer(args[1]);
                if (target == null) {
                    sender.sendMessage(plugin.colorize("&cPlayer not found or offline."));
                    return true;
                }
                plugin.getViolationManager().resetAll(target.getUniqueId());
                sender.sendMessage(plugin.colorize("&aCleared all violations for " + target.getName() + "."));
            }
            default -> sendUsage(sender);
        }
        return true;
    }

    private long parseLongSafe(String s, long def) {
        try {
            return Long.parseLong(s);
        } catch (NumberFormatException e) {
            return def;
        }
    }

    private void sendUsage(CommandSender sender) {
        sender.sendMessage(plugin.colorize("&6SentinelAC Commands:"));
        sender.sendMessage(plugin.colorize("&7/sentinel reload &8- &7Reload config.yml"));
        sender.sendMessage(plugin.colorize("&7/sentinel check <player> &8- &7View a player's violation levels"));
        sender.sendMessage(plugin.colorize("&7/sentinel exempt <player> [seconds] &8- &7Temporarily exempt a player"));
        sender.sendMessage(plugin.colorize("&7/sentinel resetviolations <player> &8- &7Clear a player's violations"));
    }
}
