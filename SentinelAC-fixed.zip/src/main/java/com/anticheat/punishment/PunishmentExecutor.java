package com.anticheat.punishment;

import com.anticheat.core.SentinelAC;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Reads the "punishments" section of config.yml and executes the
 * appropriate command stage when a player's violation level for a
 * check crosses a configured threshold. Fully customizable by editing
 * config.yml -- no code changes needed to retune punishments.
 */
public class PunishmentExecutor {

    private final SentinelAC plugin;

    public PunishmentExecutor(SentinelAC plugin) {
        this.plugin = plugin;
    }

    public void checkAndExecute(Player player, String checkName, double currentVl, Map<String, Integer> executedStages) {
        List<Stage> stages = loadStages(checkName);
        if (stages.isEmpty()) return;

        int highestStageIndex = -1;
        for (int i = 0; i < stages.size(); i++) {
            if (currentVl >= stages.get(i).atViolations) {
                highestStageIndex = i;
            }
        }
        if (highestStageIndex == -1) return;

        int alreadyExecuted = executedStages.getOrDefault(checkName, -1);
        if (highestStageIndex <= alreadyExecuted) return; // already ran this or a later stage

        Stage stage = stages.get(highestStageIndex);
        executedStages.put(checkName, highestStageIndex);

        for (String rawCommand : stage.commands) {
            executeCommand(player, rawCommand);
        }
    }

    private void executeCommand(Player player, String rawCommand) {
        String command = rawCommand.replace("%player%", player.getName());

        // Run on the main thread since this may be called from async packet listeners
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (command.startsWith("console:")) {
                String actual = command.substring("console:".length());
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), actual);
            } else if (command.startsWith("broadcast:")) {
                String msg = command.substring("broadcast:".length());
                Bukkit.broadcastMessage(plugin.colorize(msg));
            } else if (command.equalsIgnoreCase("kick")) {
                player.kick(net.kyori.adventure.text.Component.text(
                        plugin.colorize("&cKicked by SentinelAC: suspicious activity detected")));
            } else if (command.equalsIgnoreCase("ban")) {
                // Bans by player name (BanList.Type.NAME) are no longer
                // supported on modern Paper -- addBan() silently no-ops.
                // Player#ban() bans by UUID/profile, which actually works.
                player.ban("Cheating detected by SentinelAC", (java.time.Duration) null, "SentinelAC");
                player.kick(net.kyori.adventure.text.Component.text(
                        plugin.colorize("&cBanned by SentinelAC: cheating detected")));
            } else if (command.equalsIgnoreCase("ban-ip")) {
                String ip = player.getAddress() != null ? player.getAddress().getAddress().getHostAddress() : null;
                if (ip != null) {
                    Bukkit.getBanList(org.bukkit.BanList.Type.IP).addBan(ip,
                            "Cheating detected by SentinelAC", null, "SentinelAC");
                }
                player.kick(net.kyori.adventure.text.Component.text(
                        plugin.colorize("&cBanned by SentinelAC: cheating detected")));
            } else {
                // Treat as a raw console command for flexibility
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), command);
            }
        });
    }

    private List<Stage> loadStages(String checkName) {
        List<Stage> stages = new ArrayList<>();
        ConfigurationSection punishmentsSection = plugin.getConfig().getConfigurationSection("punishments");
        if (punishmentsSection == null) return stages;

        ConfigurationSection overrideSection = punishmentsSection.getConfigurationSection("overrides." + checkName);
        ConfigurationSection sourceSection = overrideSection != null
                ? overrideSection
                : punishmentsSection.getConfigurationSection("default");

        if (sourceSection == null) return stages;

        List<Map<?, ?>> stageList = sourceSection.getMapList("stages");
        for (Map<?, ?> stageMap : stageList) {
            int atViolations = stageMap.get("at-violations") instanceof Number
                    ? ((Number) stageMap.get("at-violations")).intValue() : 0;
            @SuppressWarnings("unchecked")
            List<String> commands = (List<String>) stageMap.getOrDefault("commands", List.of());
            stages.add(new Stage(atViolations, commands));
        }
        stages.sort((a, b) -> Integer.compare(a.atViolations, b.atViolations));
        return stages;
    }

    private record Stage(int atViolations, List<String> commands) {
    }
}
