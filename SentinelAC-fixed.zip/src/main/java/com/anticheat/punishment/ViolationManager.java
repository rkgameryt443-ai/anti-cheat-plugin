package com.anticheat.punishment;

import com.anticheat.core.SentinelAC;
import org.bukkit.entity.Player;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Tracks violation levels (VL) per player per check name.
 * VLs decay over time (configurable) and trigger punishment stages
 * when thresholds are crossed.
 */
public class ViolationManager {

    private final SentinelAC plugin;
    // playerUUID -> (checkName -> violation level)
    private final Map<UUID, Map<String, Double>> violations = new ConcurrentHashMap<>();
    // playerUUID -> (checkName -> last violation timestamp)
    private final Map<UUID, Map<String, Long>> lastViolationTime = new ConcurrentHashMap<>();
    // playerUUID -> (checkName -> highest stage already executed)
    private final Map<UUID, Map<String, Integer>> executedStages = new ConcurrentHashMap<>();

    public ViolationManager(SentinelAC plugin) {
        this.plugin = plugin;
    }

    /**
     * Add a violation for the given player/check, fire an alert, and
     * trigger punishment escalation if a new stage threshold is crossed.
     *
     * @param player    the offending player
     * @param checkName lowercase check identifier, e.g. "killaura"
     * @param amount    how much VL to add (typically 1.0)
     * @param details   human-readable details for staff alerts/logs
     */
    public void flag(Player player, String checkName, double amount, String details) {
        UUID uuid = player.getUniqueId();
        Map<String, Double> playerViolations = violations.computeIfAbsent(uuid, k -> new ConcurrentHashMap<>());
        double newVl = playerViolations.merge(checkName, amount, Double::sum);

        lastViolationTime.computeIfAbsent(uuid, k -> new ConcurrentHashMap<>())
                .put(checkName, System.currentTimeMillis());

        plugin.getAlertManager().sendAlert(player, checkName, newVl, details);

        plugin.getPunishmentExecutor().checkAndExecute(player, checkName, newVl,
                executedStages.computeIfAbsent(uuid, k -> new ConcurrentHashMap<>()));
    }

    public double getViolationLevel(UUID uuid, String checkName) {
        Map<String, Double> playerViolations = violations.get(uuid);
        if (playerViolations == null) return 0.0;
        return playerViolations.getOrDefault(checkName, 0.0);
    }

    public Map<String, Double> getAllViolations(UUID uuid) {
        return violations.getOrDefault(uuid, Map.of());
    }

    /**
     * Decay all violation levels by 1 point if their last violation time
     * is older than the configured decay interval. Called periodically
     * by a repeating task.
     */
    public void decayAll(long decayIntervalMs) {
        long now = System.currentTimeMillis();
        for (Map.Entry<UUID, Map<String, Double>> entry : violations.entrySet()) {
            UUID uuid = entry.getKey();
            Map<String, Long> lastTimes = lastViolationTime.get(uuid);
            if (lastTimes == null) continue;

            for (Map.Entry<String, Double> vlEntry : entry.getValue().entrySet()) {
                String check = vlEntry.getKey();
                Long lastTime = lastTimes.get(check);
                if (lastTime == null) continue;

                if (now - lastTime >= decayIntervalMs && vlEntry.getValue() > 0) {
                    vlEntry.setValue(Math.max(0, vlEntry.getValue() - 1));
                    lastTimes.put(check, now);
                }
            }
        }
    }

    public void clearPlayer(UUID uuid) {
        violations.remove(uuid);
        lastViolationTime.remove(uuid);
        executedStages.remove(uuid);
    }

    public void resetCheck(UUID uuid, String checkName) {
        Map<String, Double> playerViolations = violations.get(uuid);
        if (playerViolations != null) playerViolations.remove(checkName);
        Map<String, Integer> stages = executedStages.get(uuid);
        if (stages != null) stages.remove(checkName);
    }

    public void resetAll(UUID uuid) {
        violations.remove(uuid);
        executedStages.remove(uuid);
    }
}
