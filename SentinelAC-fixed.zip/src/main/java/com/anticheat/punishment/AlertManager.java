package com.anticheat.punishment;

import com.anticheat.core.SentinelAC;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.logging.Level;

/**
 * Sends real-time chat alerts to online staff (sentinelac.alerts permission)
 * whenever a check flags a player, and logs to console.
 */
public class AlertManager {

    private final SentinelAC plugin;

    public AlertManager(SentinelAC plugin) {
        this.plugin = plugin;
    }

    public void sendAlert(Player player, String checkName, double vl, String details) {
        if (!plugin.getConfig().getBoolean("settings.alerts-enabled", true)) return;

        String prefix = plugin.getConfig().getString("settings.alert-prefix", "&8[&cSentinelAC&8] &7");
        String formattedVl = String.format("%.1f", vl);

        String message = plugin.colorize(prefix) + plugin.colorize("&f" + player.getName()
                + " &7failed &c" + checkName.toUpperCase() + " &7(VL: &e" + formattedVl + "&7) "
                + (details != null && !details.isEmpty() ? "&8- &7" + details : ""));

        for (Player staff : Bukkit.getOnlinePlayers()) {
            if (staff.hasPermission("sentinelac.alerts")) {
                staff.sendMessage(message);
            }
        }

        if (plugin.getConfig().getBoolean("settings.debug", false)) {
            plugin.getLogger().log(Level.INFO, "[ALERT] " + player.getName() + " failed " + checkName
                    + " VL=" + formattedVl + " details=" + details);
        }
    }
}
