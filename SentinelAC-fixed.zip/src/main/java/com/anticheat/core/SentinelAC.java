package com.anticheat.core;

import com.anticheat.commands.SentinelCommand;
import com.anticheat.data.PlayerDataManager;
import com.anticheat.listeners.CombatListener;
import com.anticheat.listeners.MovementListener;
import com.anticheat.listeners.PlayerLifecycleListener;
import com.anticheat.listeners.WorldListener;
import com.anticheat.punishment.AlertManager;
import com.anticheat.punishment.PunishmentExecutor;
import com.anticheat.punishment.ViolationManager;
import org.bukkit.ChatColor;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

public class SentinelAC extends JavaPlugin {

    private PlayerDataManager playerDataManager;
    private ViolationManager violationManager;
    private PunishmentExecutor punishmentExecutor;
    private AlertManager alertManager;

    private BukkitTask decayTask;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        this.playerDataManager = new PlayerDataManager();
        this.violationManager = new ViolationManager(this);
        this.punishmentExecutor = new PunishmentExecutor(this);
        this.alertManager = new AlertManager(this);

        registerListeners();
        registerCommands();
        startDecayTask();

        getLogger().info("SentinelAC enabled — broad detection active (movement, combat, world, packet integrity).");
    }

    @Override
    public void onDisable() {
        if (decayTask != null) decayTask.cancel();
        if (playerDataManager != null) playerDataManager.clear();
        getLogger().info("SentinelAC disabled.");
    }

    private void registerListeners() {
        getServer().getPluginManager().registerEvents(new MovementListener(this), this);
        getServer().getPluginManager().registerEvents(new CombatListener(this), this);
        getServer().getPluginManager().registerEvents(new WorldListener(this), this);
        getServer().getPluginManager().registerEvents(new PlayerLifecycleListener(this), this);
    }

    private void registerCommands() {
        var sentinelCommand = new SentinelCommand(this);
        var command = getCommand("sentinel");
        if (command != null) {
            command.setExecutor(sentinelCommand);
        } else {
            getLogger().warning("Could not register /sentinel command - check plugin.yml");
        }
    }

    private void startDecayTask() {
        long decaySeconds = getConfig().getLong("settings.violation-decay-seconds", 30);
        long decayTicks = decaySeconds * 20L;
        decayTask = getServer().getScheduler().runTaskTimerAsynchronously(this, () -> {
            violationManager.decayAll(decaySeconds * 1000);
        }, decayTicks, decayTicks);
    }

    /**
     * Translates '&' color codes to Minecraft formatting codes.
     */
    public String colorize(String input) {
        return ChatColor.translateAlternateColorCodes('&', input);
    }

    public PlayerDataManager getPlayerDataManager() {
        return playerDataManager;
    }

    public ViolationManager getViolationManager() {
        return violationManager;
    }

    public PunishmentExecutor getPunishmentExecutor() {
        return punishmentExecutor;
    }

    public AlertManager getAlertManager() {
        return alertManager;
    }
}
