package com.anticheat.listeners;

import com.anticheat.core.SentinelAC;
import com.anticheat.data.PlayerData;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityToggleGlideEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerToggleFlightEvent;
import org.bukkit.event.vehicle.VehicleEnterEvent;
import org.bukkit.event.vehicle.VehicleExitEvent;

public class PlayerLifecycleListener implements Listener {

    private final SentinelAC plugin;

    public PlayerLifecycleListener(SentinelAC plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        plugin.getPlayerDataManager().get(event.getPlayer());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        plugin.getPlayerDataManager().remove(event.getPlayer());
        plugin.getViolationManager().clearPlayer(event.getPlayer().getUniqueId());
    }

    @EventHandler
    public void onToggleFlight(PlayerToggleFlightEvent event) {
        PlayerData data = plugin.getPlayerDataManager().get(event.getPlayer());
        data.setFlyingAllowed(event.getPlayer().getAllowFlight());
        // brief exemption while toggling to avoid a one-tick false flag
        data.setExemptFor(500);
    }

    @EventHandler
    public void onToggleGlide(EntityToggleGlideEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        PlayerData data = plugin.getPlayerDataManager().get(player);
        data.setGliding(event.isGliding());
        data.setExemptFor(500);
    }

    @EventHandler
    public void onVehicleEnter(VehicleEnterEvent event) {
        if (!(event.getEntered() instanceof Player player)) return;
        PlayerData data = plugin.getPlayerDataManager().get(player);
        data.setInVehicle(true);
    }

    @EventHandler
    public void onVehicleExit(VehicleExitEvent event) {
        if (!(event.getExited() instanceof Player player)) return;
        PlayerData data = plugin.getPlayerDataManager().get(player);
        data.setInVehicle(false);
        data.setExemptFor(500);
    }
}
