package com.anticheat.listeners;

import com.anticheat.checks.world.FastBreakCheck;
import com.anticheat.checks.world.FastPlaceCheck;
import com.anticheat.checks.world.ScaffoldCheck;
import com.anticheat.core.SentinelAC;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;

public class WorldListener implements Listener {

    private final FastBreakCheck fastBreakCheck;
    private final FastPlaceCheck fastPlaceCheck;
    private final ScaffoldCheck scaffoldCheck;

    public WorldListener(SentinelAC plugin) {
        this.fastBreakCheck = new FastBreakCheck(plugin);
        this.fastPlaceCheck = new FastPlaceCheck(plugin);
        this.scaffoldCheck = new ScaffoldCheck(plugin);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        fastBreakCheck.check(event);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBlockPlace(BlockPlaceEvent event) {
        fastPlaceCheck.check(event);
        scaffoldCheck.check(event);
    }
}
