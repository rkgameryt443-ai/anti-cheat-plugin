package com.anticheat.listeners;

import com.anticheat.checks.combat.AutoClickerCheck;
import com.anticheat.checks.combat.KillAuraCheck;
import com.anticheat.checks.combat.ReachCheck;
import com.anticheat.checks.combat.VelocityCheck;
import com.anticheat.core.SentinelAC;
import com.anticheat.data.PlayerData;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import io.papermc.paper.event.entity.EntityKnockbackByEntityEvent;
import org.bukkit.event.player.PlayerMoveEvent;

public class CombatListener implements Listener {

    private final SentinelAC plugin;
    private final KillAuraCheck killAuraCheck;
    private final ReachCheck reachCheck;
    private final AutoClickerCheck autoClickerCheck;
    private final VelocityCheck velocityCheck;

    public CombatListener(SentinelAC plugin) {
        this.plugin = plugin;
        this.killAuraCheck = new KillAuraCheck(plugin);
        this.reachCheck = new ReachCheck(plugin);
        this.autoClickerCheck = new AutoClickerCheck(plugin);
        this.velocityCheck = new VelocityCheck(plugin);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player attacker)) return;

        PlayerData data = plugin.getPlayerDataManager().get(attacker);
        data.setLastAttackTime(System.currentTimeMillis());

        killAuraCheck.check(event);
        reachCheck.check(event);
        autoClickerCheck.check(event);
    }

    @EventHandler
    public void onKnockback(EntityKnockbackByEntityEvent event) {
        if (!(event.getEntity() instanceof Player victim)) return;
        PlayerData data = plugin.getPlayerDataManager().get(victim);
        var v = event.getKnockback();
        data.setLastKnockback(v.getX(), v.getY(), v.getZ());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onMoveForVelocityCheck(PlayerMoveEvent event) {
        velocityCheck.check(event);
    }
}
