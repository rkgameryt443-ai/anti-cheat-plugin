package com.anticheat.listeners;

import com.anticheat.checks.movement.*;
import com.anticheat.checks.packet.BadPacketsCheck;
import com.anticheat.checks.packet.TimerCheck;
import com.anticheat.core.SentinelAC;
import com.anticheat.data.PlayerData;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerTeleportEvent;

public class MovementListener implements Listener {

    private final SentinelAC plugin;
    private final FlightCheck flightCheck;
    private final SpeedCheck speedCheck;
    private final NoFallCheck noFallCheck;
    private final JesusCheck jesusCheck;
    private final PhaseCheck phaseCheck;
    private final StepCheck stepCheck;
    private final TimerCheck timerCheck;
    private final BadPacketsCheck badPacketsCheck;

    public MovementListener(SentinelAC plugin) {
        this.plugin = plugin;
        this.flightCheck = new FlightCheck(plugin);
        this.speedCheck = new SpeedCheck(plugin);
        this.noFallCheck = new NoFallCheck(plugin);
        this.jesusCheck = new JesusCheck(plugin);
        this.phaseCheck = new PhaseCheck(plugin);
        this.stepCheck = new StepCheck(plugin);
        this.timerCheck = new TimerCheck(plugin);
        this.badPacketsCheck = new BadPacketsCheck(plugin);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlayerMove(PlayerMoveEvent event) {
        if (event.getTo() == null) return;

        // Run integrity check first; cancels event and returns early on bad data.
        badPacketsCheck.check(event);
        if (event.isCancelled()) return;

        timerCheck.check(event);
        flightCheck.check(event);
        speedCheck.check(event);
        noFallCheck.check(event);
        jesusCheck.check(event);
        phaseCheck.check(event);
        stepCheck.check(event);

        PlayerData data = plugin.getPlayerDataManager().get(event.getPlayer());
        data.setLastLocation(event.getTo());
        data.setWasOnGround(event.getPlayer().isOnGround());
    }

    @EventHandler
    public void onTeleport(PlayerTeleportEvent event) {
        PlayerData data = plugin.getPlayerDataManager().get(event.getPlayer());
        // 1.5s grace period after any teleport (plugin-triggered or vanilla)
        // to avoid flagging the resulting large positional delta as a hack.
        data.markTeleported(1500);
        data.resetAirTicks();
    }
}
