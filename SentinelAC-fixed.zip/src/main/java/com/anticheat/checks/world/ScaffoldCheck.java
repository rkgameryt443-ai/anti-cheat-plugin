package com.anticheat.checks.world;

import com.anticheat.checks.Check;
import com.anticheat.core.SentinelAC;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;
import org.bukkit.event.block.BlockPlaceEvent;

/**
 * Detects Scaffold: automated bridge-building hacks that place blocks
 * beneath the player while sprinting/walking backward without the
 * player actually looking anywhere near downward (legitimate manual
 * bridging requires looking down-ish at the placement target).
 */
public class ScaffoldCheck extends Check {

    private static final float MAX_PITCH_FOR_DOWNWARD_PLACE = 40.0f; // degrees above horizontal still "looking down enough"

    public ScaffoldCheck(SentinelAC plugin) {
        super(plugin, "scaffold", "checks.world.scaffold");
    }

    public void check(BlockPlaceEvent event) {
        if (!isEnabled()) return;
        Player player = event.getPlayer();
        if (player.getGameMode() == GameMode.CREATIVE) return;

        boolean placingBelow = event.getBlock().getY() < player.getLocation().getBlockY();
        if (!placingBelow) return;

        float pitch = player.getLocation().getPitch();

        // Vanilla pitch is positive when looking down. Placing a block
        // directly underfoot while looking level or upward (pitch below
        // the "looking down enough" threshold) while sprinting is the
        // classic scaffold signature -- a human bridging manually looks
        // down at the edge, so pitch should be well above 0.
        if (player.isSprinting() && pitch < MAX_PITCH_FOR_DOWNWARD_PLACE) {
            flag(player, "pitch=" + String.format("%.1f", pitch) + " sprinting=true");
        }
    }
}
