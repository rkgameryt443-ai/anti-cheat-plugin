package com.anticheat.checks.world;

import com.anticheat.checks.Check;
import com.anticheat.core.SentinelAC;
import com.anticheat.data.PlayerData;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.inventory.ItemStack;

/**
 * Detects FastBreak: breaking blocks faster than vanilla mining mechanics
 * allow given the tool, material hardness, and effects. This uses a
 * simplified hardness-based estimate rather than exact vanilla mining
 * formulas (which depend on enchantments, tool tier, haste/mining
 * fatigue, and whether the player is in water/on ground) -- the
 * threshold is intentionally generous to avoid false positives, biased
 * toward catching only egregious instant-break hacks.
 */
public class FastBreakCheck extends Check {

    private static final long MIN_BREAK_TIME_MS = 50; // generous floor; real instant-break hacks go near 0ms

    public FastBreakCheck(SentinelAC plugin) {
        super(plugin, "fastbreak", "checks.world.fastbreak");
    }

    public void check(BlockBreakEvent event) {
        if (!isEnabled()) return;
        Player player = event.getPlayer();
        if (player.getGameMode() == GameMode.CREATIVE) return;

        PlayerData data = plugin.getPlayerDataManager().get(player);
        long now = System.currentTimeMillis();
        long timeSinceLastBreak = now - data.getLastBlockBreakTime();
        data.setLastBlockBreakTime(now);

        Material material = event.getBlock().getType();
        float hardness = material.getHardness();

        // Instant-break blocks (hardness 0, e.g. tall grass, torches) are exempt.
        if (hardness <= 0f) return;

        ItemStack tool = player.getInventory().getItemInMainHand();
        boolean hasEfficiency = tool.containsEnchantment(org.bukkit.enchantments.Enchantment.EFFICIENCY);

        long minExpected = hasEfficiency ? MIN_BREAK_TIME_MS / 2 : MIN_BREAK_TIME_MS;

        // Only flag harder blocks; very soft blocks (dirt, sand) can legitimately
        // break in a couple ticks even with weak tools.
        if (hardness >= 1.5f && timeSinceLastBreak < minExpected && timeSinceLastBreak > 0) {
            flag(player, "block=" + material + " time=" + timeSinceLastBreak + "ms hardness=" + hardness);
        }
    }
}
