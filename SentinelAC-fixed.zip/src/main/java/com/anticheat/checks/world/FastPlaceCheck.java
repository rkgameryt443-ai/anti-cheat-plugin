package com.anticheat.checks.world;

import com.anticheat.checks.Check;
import com.anticheat.core.SentinelAC;
import com.anticheat.data.PlayerData;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;
import org.bukkit.event.block.BlockPlaceEvent;

/**
 * Detects FastPlace: placing blocks at a rate beyond vanilla's
 * per-tick interaction limit (~4 blocks/sec is roughly the legitimate
 * ceiling for fast manual clicking; vanilla itself throttles to about
 * 1 placement per game tick under normal interaction conditions).
 */
public class FastPlaceCheck extends Check {

    private static final long MIN_PLACE_INTERVAL_MS = 90;

    public FastPlaceCheck(SentinelAC plugin) {
        super(plugin, "fastplace", "checks.world.fastplace");
    }

    public void check(BlockPlaceEvent event) {
        if (!isEnabled()) return;
        Player player = event.getPlayer();
        if (player.getGameMode() == GameMode.CREATIVE) return;

        PlayerData data = plugin.getPlayerDataManager().get(player);
        long now = System.currentTimeMillis();
        long sinceLast = now - data.getLastBlockPlaceTime();
        data.setLastBlockPlaceTime(now);

        if (sinceLast < MIN_PLACE_INTERVAL_MS && sinceLast > 0) {
            data.incrementConsecutivePlacements();
            if (data.getConsecutivePlacements() >= 3) {
                flag(player, "interval=" + sinceLast + "ms consecutive=" + data.getConsecutivePlacements());
            }
        } else {
            data.resetConsecutivePlacements();
        }
    }
}
