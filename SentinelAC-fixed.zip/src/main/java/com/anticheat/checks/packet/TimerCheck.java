package com.anticheat.checks.packet;

import com.anticheat.checks.Check;
import com.anticheat.core.SentinelAC;
import com.anticheat.data.PlayerData;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerMoveEvent;

/**
 * Detects Timer hacks: clients that send movement packets at a higher
 * frequency than the server tick rate (20/sec) allows, effectively
 * speeding up their game logic relative to real time.
 *
 * NOTE: This implementation counts PlayerMoveEvent frequency as a proxy
 * for packet frequency, which Paper fires once per movement packet.
 * For stricter / more accurate detection (counting raw packets
 * including ones Paper may coalesce), wire this check into a
 * ProtocolLib PacketListener on PacketType.Play.Client.POSITION and
 * its variants instead -- see the class javadoc in PacketListener.
 */
public class TimerCheck extends Check {

    private static final long WINDOW_MS = 1000;
    private static final int MAX_PACKETS_PER_WINDOW = 22; // 20 ticks/sec + small buffer for lag bursts

    public TimerCheck(SentinelAC plugin) {
        super(plugin, "timer", "checks.packet.timer");
    }

    public void check(PlayerMoveEvent event) {
        if (!isEnabled()) return;
        Player player = event.getPlayer();
        PlayerData data = plugin.getPlayerDataManager().get(player);

        long now = System.currentTimeMillis();
        if (now - data.getLastTimerCheckTime() > WINDOW_MS) {
            data.setLastTimerCheckTime(now);
            data.resetTimerPacketCount();
        }
        data.incrementTimerPacketCount();

        if (data.getTimerPacketCount() > MAX_PACKETS_PER_WINDOW) {
            flag(player, "packets/sec=" + data.getTimerPacketCount());
        }
    }
}
