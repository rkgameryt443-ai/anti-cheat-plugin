package com.anticheat.checks.packet;

import com.anticheat.checks.Check;
import com.anticheat.core.SentinelAC;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerMoveEvent;

/**
 * Detects malformed movement data that legitimate vanilla clients never
 * produce: NaN/infinite coordinates, invalid pitch (must be -90 to 90),
 * or yaw/coordinate values outside the world border. This catches
 * crash-exploit and packet-manipulation tools rather than typical
 * movement-speed cheats.
 */
public class BadPacketsCheck extends Check {

    public BadPacketsCheck(SentinelAC plugin) {
        super(plugin, "badpackets", "checks.packet.badpackets");
    }

    public void check(PlayerMoveEvent event) {
        if (!isEnabled()) return;
        Player player = event.getPlayer();
        Location to = event.getTo();
        if (to == null) return;

        if (!isFinite(to.getX()) || !isFinite(to.getY()) || !isFinite(to.getZ())) {
            flag(player, "non-finite coordinates");
            event.setCancelled(true);
            return;
        }

        float pitch = to.getPitch();
        if (pitch < -90.0f || pitch > 90.0f) {
            flag(player, "invalid pitch=" + pitch);
            event.setCancelled(true);
            return;
        }

        var border = player.getWorld().getWorldBorder();
        double halfSize = border.getSize() / 2.0 + 1000; // generous margin
        org.bukkit.Location center = border.getCenter();
        if (Math.abs(to.getX() - center.getX()) > halfSize || Math.abs(to.getZ() - center.getZ()) > halfSize) {
            flag(player, "coordinates outside world border");
            event.setCancelled(true);
        }
    }

    private boolean isFinite(double value) {
        return !Double.isNaN(value) && !Double.isInfinite(value);
    }
}
