package com.anticheat.checks;

import com.anticheat.core.SentinelAC;
import org.bukkit.entity.Player;

/**
 * Base class for all cheat detection checks. Each concrete check
 * (e.g. FlightCheck, KillAuraCheck) extends this and implements its
 * own detection logic, calling flag() when it detects suspicious behavior.
 */
public abstract class Check {

    protected final SentinelAC plugin;
    private final String name;
    private final String configPath;

    protected Check(SentinelAC plugin, String name, String configPath) {
        this.plugin = plugin;
        this.name = name;
        this.configPath = configPath;
    }

    public String getName() {
        return name;
    }

    public boolean isEnabled() {
        return plugin.getConfig().getBoolean(configPath + ".enabled", true);
    }

    protected double getConfigDouble(String key, double def) {
        return plugin.getConfig().getDouble(configPath + "." + key, def);
    }

    protected int getConfigInt(String key, int def) {
        return plugin.getConfig().getInt(configPath + "." + key, def);
    }

    /**
     * Flags the player for this check. Adds 1.0 violation level by default.
     */
    protected void flag(Player player, String details) {
        flag(player, 1.0, details);
    }

    protected void flag(Player player, double amount, String details) {
        if (shouldBypass(player)) return;
        plugin.getViolationManager().flag(player, name, amount, details);
    }

    /**
     * Players with the bypass permission or active exemption are never flagged.
     * This covers legitimate edge cases (server-granted flight, elytra, etc.)
     * without disabling the check entirely.
     */
    protected boolean shouldBypass(Player player) {
        if (player.hasPermission("sentinelac.bypass")) return true;
        var data = plugin.getPlayerDataManager().get(player);
        return data.isExempt();
    }
}
