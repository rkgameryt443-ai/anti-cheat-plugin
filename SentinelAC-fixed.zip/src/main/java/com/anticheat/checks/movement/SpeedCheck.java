package com.anticheat.checks.movement;

import com.anticheat.checks.Check;
import com.anticheat.core.SentinelAC;
import com.anticheat.data.PlayerData;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.potion.PotionEffectType;

/**
 * Detects horizontal movement exceeding the maximum plausible speed for
 * the player's current state (walking/sprinting, potion effects, ice,
 * etc). Uses a generous dynamic cap rather than a single hardcoded
 * number to reduce false positives from speed potions, soul sand,
 * slime bounces, and knockback.
 */
public class SpeedCheck extends Check {

    private static final double BASE_WALK_SPEED = 0.221; // blocks/tick baseline sprint-jump speed
    private static final double KNOCKBACK_GRACE_MS = 500;

    public SpeedCheck(SentinelAC plugin) {
        super(plugin, "speed", "checks.movement.speed");
    }

    public void check(PlayerMoveEvent event) {
        if (!isEnabled()) return;
        Player player = event.getPlayer();

        if (player.getGameMode() == GameMode.CREATIVE || player.getGameMode() == GameMode.SPECTATOR) return;
        if (player.getVehicle() != null) return;

        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data.isJustTeleported()) return;

        // Grace period after knockback/explosion -- vanilla velocity can
        // briefly exceed normal speed caps legitimately.
        if (System.currentTimeMillis() - data.getLastVelocityApplied() < KNOCKBACK_GRACE_MS) return;

        double dx = event.getTo().getX() - event.getFrom().getX();
        double dz = event.getTo().getZ() - event.getFrom().getZ();
        double horizontalDistance = Math.sqrt(dx * dx + dz * dz);

        double allowedSpeed = computeAllowedSpeed(player);

        if (horizontalDistance > allowedSpeed) {
            double overshoot = horizontalDistance - allowedSpeed;
            // Scale flag amount slightly with how far over the limit they are,
            // so minor lag-induced overshoot doesn't punish as hard as a clear hack.
            double amount = overshoot > allowedSpeed ? 1.5 : 1.0;
            flag(player, amount, "dist=" + String.format("%.3f", horizontalDistance)
                    + " allowed=" + String.format("%.3f", allowedSpeed));
        }
    }

    private double computeAllowedSpeed(Player player) {
        double speed = BASE_WALK_SPEED;

        if (player.isSprinting()) speed *= 1.3;

        int speedAmplifier = -1;
        if (player.hasPotionEffect(PotionEffectType.SPEED)) {
            speedAmplifier = player.getPotionEffect(PotionEffectType.SPEED).getAmplifier();
        }
        if (speedAmplifier >= 0) {
            speed *= 1.0 + (0.2 * (speedAmplifier + 1));
        }

        // Ice and slime blocks allow significantly higher slide speeds;
        // give a generous flat multiplier rather than block-sampling every
        // tick for performance reasons.
        speed *= 2.6; // generous ceiling covering ice slides, soul sand sprint-jumps, slime bounces

        return speed;
    }
}
