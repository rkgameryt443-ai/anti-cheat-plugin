package com.anticheat.checks.movement;

import com.anticheat.checks.Check;
import com.anticheat.core.SentinelAC;
import com.anticheat.data.PlayerData;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerMoveEvent;

/**
 * Detects "Jesus" hacks: walking on top of liquid surfaces. Legitimate
 * ways to do this are boats, frost walker boots (ice, not direct water-walk),
 * and turtle-master-style edge cases are rare; we check the block at and
 * just below feet level for liquid while the player is reported on-ground.
 */
public class JesusCheck extends Check {

    public JesusCheck(SentinelAC plugin) {
        super(plugin, "jesus", "checks.movement.jesus");
    }

    public void check(PlayerMoveEvent event) {
        if (!isEnabled()) return;
        Player player = event.getPlayer();
        if (player.getGameMode() == GameMode.CREATIVE || player.getGameMode() == GameMode.SPECTATOR) return;
        if (player.getVehicle() != null) return; // boats are legitimate

        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data.isJustTeleported()) return;

        if (!player.isOnGround()) return;

        Material feetBlock = event.getTo().getBlock().getType();
        Material belowBlock = event.getTo().clone().subtract(0, 1, 0).getBlock().getType();

        boolean onLiquidSurface = (feetBlock == Material.WATER || feetBlock == Material.LAVA)
                && belowBlock != Material.ICE && belowBlock != Material.PACKED_ICE
                && belowBlock != Material.BLUE_ICE && belowBlock != Material.FROSTED_ICE
                && (belowBlock == Material.WATER || belowBlock == Material.LAVA);

        if (onLiquidSurface) {
            // Player's bounding box is fully within liquid blocks yet the
            // server still reports on-ground=true -- not physically possible
            // without a hack intercepting buoyancy/swim state.
            flag(player, "feet=" + feetBlock + " below=" + belowBlock);
        }
    }
}
