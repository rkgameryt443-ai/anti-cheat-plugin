package com.anticheat.checks.movement;

import com.anticheat.checks.Check;
import com.anticheat.core.SentinelAC;
import com.anticheat.data.PlayerData;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.potion.PotionEffectType;

/**
 * Detects NoFall: client-side suppression of fall damage. Tracks
 * accumulated fall distance and verifies that landing on ground after
 * a significant fall actually registers as on-ground correctly without
 * the player's tracked fall distance being suspiciously reset.
 *
 * Real fall-damage validation happens via Bukkit's own fall damage
 * system; this check focuses on detecting the common NoFall pattern of
 * the client reporting on-ground=true falsely for a single tick to
 * cancel fall damage, then immediately reporting on-ground=false again
 * while still clearly airborne (no solid block beneath).
 */
public class NoFallCheck extends Check {

    private static final double SIGNIFICANT_FALL_DISTANCE = 3.5;

    public NoFallCheck(SentinelAC plugin) {
        super(plugin, "nofall", "checks.movement.nofall");
    }

    public void check(PlayerMoveEvent event) {
        if (!isEnabled()) return;
        Player player = event.getPlayer();
        if (player.getGameMode() == GameMode.CREATIVE || player.getGameMode() == GameMode.SPECTATOR) return;
        if (player.getVehicle() != null) return;
        if (player.isGliding() || player.isSwimming()) return;
        if (player.hasPotionEffect(PotionEffectType.SLOW_FALLING)) return;

        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data.isJustTeleported()) return;

        boolean onGround = player.isOnGround();
        double fallDistance = player.getFallDistance();

        // Client claims on-ground with a large accumulated fall distance,
        // but the block directly beneath isn't actually solid -- classic
        // ground-spoof NoFall packet pattern.
        if (onGround && fallDistance >= SIGNIFICANT_FALL_DISTANCE) {
            var blockBelow = player.getLocation().clone().subtract(0, 0.1, 0).getBlock();
            if (!blockBelow.getType().isSolid()) {
                flag(player, "fallDistance=" + String.format("%.2f", fallDistance) + " groundSpoof");
            }
        }
    }
}
