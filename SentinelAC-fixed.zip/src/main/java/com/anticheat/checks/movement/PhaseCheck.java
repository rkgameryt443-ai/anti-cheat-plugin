package com.anticheat.checks.movement;

import com.anticheat.checks.Check;
import com.anticheat.core.SentinelAC;
import com.anticheat.data.PlayerData;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.util.BoundingBox;

/**
 * Detects phase/no-clip: moving into a position that overlaps a solid,
 * non-passable block. Checks the destination location's bounding box
 * against the block grid for full-cube solid blocks (ignores partial
 * blocks like slabs/stairs/fences to avoid false positives, since exact
 * collision shapes are expensive to replicate here).
 */
public class PhaseCheck extends Check {

    public PhaseCheck(SentinelAC plugin) {
        super(plugin, "phase", "checks.movement.phase");
    }

    public void check(PlayerMoveEvent event) {
        if (!isEnabled()) return;
        Player player = event.getPlayer();
        if (player.getGameMode() == GameMode.CREATIVE || player.getGameMode() == GameMode.SPECTATOR) return;
        if (player.getVehicle() != null) return;

        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data.isJustTeleported()) return;

        Location to = event.getTo();
        Block feetBlock = to.getBlock();
        Block headBlock = to.clone().add(0, 1, 0).getBlock();

        if (isFullSolidCube(feetBlock) || isFullSolidCube(headBlock)) {
            flag(player, "block=" + feetBlock.getType());
        }
    }

    private boolean isFullSolidCube(Block block) {
        if (!block.getType().isSolid()) return false;
        // isSolid() is true for stairs/slabs/fences too; restrict to blocks
        // whose collision shape is (functionally) a full 1x1x1 cube to avoid
        // flagging players standing near partial-height blocks.
        BoundingBox box = block.getBoundingBox();
        return box.getWidthX() >= 0.99 && box.getHeight() >= 0.99 && box.getWidthZ() >= 0.99;
    }
}
