package com.anticheat.checks.movement;

import com.anticheat.checks.Check;
import com.anticheat.core.SentinelAC;
import com.anticheat.data.PlayerData;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerMoveEvent;

/**
 * Detects "step" hacks that let players climb blocks taller than
 * vanilla's 0.6-block auto-step without jumping. Compares vertical
 * delta on ground-to-ground transitions.
 */
public class StepCheck extends Check {

    private static final double MAX_LEGIT_STEP = 0.65; // small buffer over vanilla 0.6

    public StepCheck(SentinelAC plugin) {
        super(plugin, "step", "checks.movement.step");
    }

    public void check(PlayerMoveEvent event) {
        if (!isEnabled()) return;
        Player player = event.getPlayer();
        if (player.getGameMode() == GameMode.CREATIVE || player.getGameMode() == GameMode.SPECTATOR) return;
        if (player.getVehicle() != null) return;
        if (!player.isOnGround()) return;

        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data.isJustTeleported()) return;
        if (!data.wasOnGround()) {
            // only check ground-to-ground transitions (rules out jumping, which
            // has its own legitimate higher arc)
            data.setWasOnGround(true);
            return;
        }

        double deltaY = event.getTo().getY() - event.getFrom().getY();

        if (deltaY > MAX_LEGIT_STEP) {
            flag(player, "stepHeight=" + String.format("%.3f", deltaY));
        }
    }
}
