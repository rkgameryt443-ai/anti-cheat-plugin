package com.anticheat.checks.movement;

import com.anticheat.checks.Check;
import com.anticheat.core.SentinelAC;
import com.anticheat.data.PlayerData;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.potion.PotionEffectType;

/**
 * Detects sustained unsupported flight.
 *
 * Approach: track consecutive air ticks. Legitimate falling produces an
 * accelerating *downward* delta-Y each tick (gravity). If a player stays
 * airborne for many ticks without that expected downward trend -- i.e.
 * their vertical position holds steady or rises -- without elytra,
 * levitation, or being in a vehicle, it's a strong flight indicator.
 *
 * This is intentionally conservative (high air-tick threshold + trend
 * check) to avoid flagging legitimate jumps, slow-falling potions, etc.
 * Jump boost / slow falling / levitation are exempted via potion checks.
 */
public class FlightCheck extends Check {

    private static final int MIN_AIR_TICKS_BEFORE_CHECK = 20; // 1 second grace after leaving ground
    private static final double EXPECTED_GRAVITY_DELTA = -0.08; // approx per-tick fall acceleration baseline

    public FlightCheck(SentinelAC plugin) {
        super(plugin, "flight", "checks.movement.flight");
    }

    public void check(PlayerMoveEvent event) {
        if (!isEnabled()) return;
        Player player = event.getPlayer();

        if (player.getGameMode() == GameMode.CREATIVE || player.getGameMode() == GameMode.SPECTATOR) return;
        if (player.isFlying() || player.getAllowFlight()) return;
        if (player.isGliding()) return; // elytra
        if (player.isSwimming() || player.isInWater() || player.isInLava()) return;
        if (player.getVehicle() != null) return;
        if (player.hasPotionEffect(PotionEffectType.LEVITATION)) return;
        if (player.hasPotionEffect(PotionEffectType.SLOW_FALLING)) return;

        PlayerData data = plugin.getPlayerDataManager().get(player);

        if (player.isOnGround()) {
            data.resetAirTicks();
            return;
        }

        data.incrementAirTicks();

        if (data.isJustTeleported()) return;
        if (data.getAirTicks() < MIN_AIR_TICKS_BEFORE_CHECK) return;

        double deltaY = event.getTo().getY() - event.getFrom().getY();

        // Once past the grace period, a legitimately falling/jumping player's
        // vertical delta should trend negative and roughly follow gravity.
        // If delta stays at or above a near-zero/positive value for sustained
        // ticks while airborne, that's unsupported lift.
        if (deltaY >= -0.01) {
            flag(player, "airTicks=" + data.getAirTicks() + " deltaY=" + String.format("%.3f", deltaY));
        }
    }
}
