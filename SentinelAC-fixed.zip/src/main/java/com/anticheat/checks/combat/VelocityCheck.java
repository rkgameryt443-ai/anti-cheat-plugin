package com.anticheat.checks.combat;

import com.anticheat.checks.Check;
import com.anticheat.core.SentinelAC;
import com.anticheat.data.PlayerData;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerMoveEvent;

/**
 * Detects anti-knockback hacks: clients that suppress or reduce the
 * velocity applied to them after taking a hit. Compares actual observed
 * horizontal displacement in the ticks following a knockback event
 * against the expected displacement from the velocity vector applied.
 */
public class VelocityCheck extends Check {

    private static final long CHECK_WINDOW_MS = 250;
    private static final double MIN_EXPECTED_RATIO = 0.4; // allow generous tolerance for client-side prediction variance

    public VelocityCheck(SentinelAC plugin) {
        super(plugin, "velocity", "checks.combat.velocity");
    }

    public void check(PlayerMoveEvent event) {
        if (!isEnabled()) return;
        Player player = event.getPlayer();
        PlayerData data = plugin.getPlayerDataManager().get(player);

        long sinceKnockback = System.currentTimeMillis() - data.getLastVelocityApplied();
        if (sinceKnockback > CHECK_WINDOW_MS || data.getLastVelocityApplied() == 0) return;
        if (player.getVehicle() != null) return;

        double expectedHorizontal = Math.sqrt(
                data.getLastKnockbackX() * data.getLastKnockbackX()
                        + data.getLastKnockbackZ() * data.getLastKnockbackZ());

        if (expectedHorizontal < 0.05) return; // negligible knockback, not worth checking

        double dx = event.getTo().getX() - event.getFrom().getX();
        double dz = event.getTo().getZ() - event.getFrom().getZ();
        double actualHorizontal = Math.sqrt(dx * dx + dz * dz);

        double ratio = actualHorizontal / expectedHorizontal;

        if (ratio < MIN_EXPECTED_RATIO) {
            flag(player, "kbRatio=" + String.format("%.2f", ratio));
        }
    }
}
