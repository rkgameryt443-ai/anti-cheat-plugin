package com.anticheat.checks.combat;

import com.anticheat.checks.Check;
import com.anticheat.core.SentinelAC;
import com.anticheat.data.PlayerData;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageByEntityEvent;

import java.util.ArrayList;
import java.util.Deque;
import java.util.List;

/**
 * Detects autoclickers via two signals:
 *  1. Raw CPS exceeding a configurable human-plausible ceiling.
 *  2. Suspiciously low variance in click intervals -- real human clicking
 *     has natural jitter; many autoclickers fire on a near-perfectly
 *     even timer.
 *
 * Both signals are checked together so legitimate fast clickers (high
 * CPS but human jitter) aren't unfairly flagged on CPS alone unless
 * they're extremely far over the ceiling.
 */
public class AutoClickerCheck extends Check {

    public AutoClickerCheck(SentinelAC plugin) {
        super(plugin, "autoclicker", "checks.combat.autoclicker");
    }

    public void check(EntityDamageByEntityEvent event) {
        if (!isEnabled()) return;
        if (!(event.getDamager() instanceof Player attacker)) return;

        PlayerData data = plugin.getPlayerDataManager().get(attacker);
        long now = System.currentTimeMillis();
        data.recordClick(now);

        int maxCps = getConfigInt("max-cps", 20);
        int cps = data.getClicksInWindow(1000);

        if (cps > maxCps + 5) {
            // Extremely high CPS alone is a strong enough signal on its own.
            flag(attacker, "cps=" + cps + " (hard ceiling)");
            return;
        }

        if (cps > maxCps) {
            Deque<Long> clicks = data.getRecentClicks();
            if (clicks.size() >= 8) {
                double variance = computeIntervalVariance(clicks);
                // Real human clicking variance is typically well above this;
                // a very low variance alongside elevated CPS strongly suggests
                // a timer-driven autoclicker.
                if (variance < 150.0) {
                    flag(attacker, "cps=" + cps + " variance=" + String.format("%.1f", variance));
                }
            }
        }
    }

    private double computeIntervalVariance(Deque<Long> clicks) {
        List<Long> list = new ArrayList<>(clicks);
        List<Long> intervals = new ArrayList<>();
        for (int i = 1; i < list.size(); i++) {
            intervals.add(list.get(i) - list.get(i - 1));
        }
        if (intervals.isEmpty()) return Double.MAX_VALUE;

        double mean = intervals.stream().mapToLong(Long::longValue).average().orElse(0);
        double variance = intervals.stream()
                .mapToDouble(i -> Math.pow(i - mean, 2))
                .average().orElse(0);
        return variance;
    }
}
