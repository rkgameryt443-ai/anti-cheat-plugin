package com.anticheat.checks.combat;

import com.anticheat.checks.Check;
import com.anticheat.core.SentinelAC;
import org.bukkit.Location;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.util.Vector;

/**
 * Detects KillAura by checking whether the attacker's view direction
 * was actually pointed at the victim at the moment of attack. Legit
 * players' crosshair angle to target should stay within a reasonable
 * cone; aim-assist/kill-aura hacks frequently attack entities far
 * outside the player's actual look direction, or attack multiple
 * targets in physically impossible angle swings within milliseconds.
 */
public class KillAuraCheck extends Check {

    public KillAuraCheck(SentinelAC plugin) {
        super(plugin, "killaura", "checks.combat.killaura");
    }

    public void check(EntityDamageByEntityEvent event) {
        if (!isEnabled()) return;
        if (!(event.getDamager() instanceof Player attacker)) return;
        if (!(event.getEntity() instanceof LivingEntity victim)) return;

        double maxAngle = getConfigDouble("max-attack-angle", 70.0);

        Location eyeLocation = attacker.getEyeLocation();
        Vector toVictim = victim.getLocation().add(0, victim.getHeight() / 2.0, 0)
                .toVector().subtract(eyeLocation.toVector());
        Vector lookDirection = eyeLocation.getDirection();

        double angle = Math.toDegrees(toVictim.normalize().angle(lookDirection.normalize()));

        if (angle > maxAngle) {
            flag(attacker, "angle=" + String.format("%.1f", angle) + " target=" + victim.getName());
        }
    }
}
