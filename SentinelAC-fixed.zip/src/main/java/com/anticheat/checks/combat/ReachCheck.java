package com.anticheat.checks.combat;

import com.anticheat.checks.Check;
import com.anticheat.core.SentinelAC;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageByEntityEvent;

/**
 * Detects extended reach: melee attacks landing from a distance beyond
 * what vanilla allows. Vanilla survival reach is ~3.0 blocks (3.0 for
 * survival, slightly more for creative). Distance is measured
 * eye-location to nearest point on victim's bounding box for accuracy.
 */
public class ReachCheck extends Check {

    public ReachCheck(SentinelAC plugin) {
        super(plugin, "reach", "checks.combat.reach");
    }

    public void check(EntityDamageByEntityEvent event) {
        if (!isEnabled()) return;
        if (!(event.getDamager() instanceof Player attacker)) return;
        if (!(event.getEntity() instanceof LivingEntity victim)) return;

        double maxReach = getConfigDouble("max-reach-distance", 3.1);

        double distance = attacker.getEyeLocation().toVector()
                .distance(victim.getBoundingBox().getCenter());

        // Subtract victim's approximate horizontal bounding radius since we
        // measured to the center, not the nearest surface point. Use width
        // (horizontal hitbox diameter), not height -- height is irrelevant
        // to reach distance and using it previously overestimated the
        // radius, letting genuine extended-reach hits slip under the cap.
        double approxRadius = victim.getWidth() / 2.0;
        double effectiveDistance = distance - approxRadius;

        if (effectiveDistance > maxReach) {
            flag(attacker, "reach=" + String.format("%.2f", effectiveDistance) + " target=" + victim.getName());
        }
    }
}
